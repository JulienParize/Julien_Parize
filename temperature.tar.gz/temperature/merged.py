import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.image import imread
from pathlib import Path

# Liste des fichiers PDF à inclure
pdf_files = [
    "TDE_n_0_histogram.pdf", 
    "TDE_n_200_histogram.pdf", 
    "TDE_n_300_histogram.pdf", 
    "TDE_n_500_histogram.pdf"
]

# Créer une figure et une grille 2x2
fig, axs = plt.subplots(2, 2, figsize=(8, 6), gridspec_kw={
    'wspace': 0.0,  # Aucun espace horizontal entre les colonnes
    'hspace': 0.0   # Aucun espace vertical entre les lignes
}, dpi=300)  # Augmenter la résolution

# Charger et afficher chaque PDF dans un sous-plot
for idx, pdf_file in enumerate(pdf_files):
    row, col = divmod(idx, 2)  # Calcul des coordonnées de la grille
    # Convertir le PDF en PNG avant utilisation (à effectuer en externe si nécessaire)
    img = imread(str(Path(pdf_file).with_suffix('.png')))
    axs[row, col].imshow(img)
    axs[row, col].axis('off')  # Désactiver les axes

# Ajuster les marges autour des graphiques
plt.subplots_adjust(
    left=0.01,   # Marge gauche minimale
    right=0.99,  # Marge droite minimale
    top=0.99,    # Marge supérieure minimale
    bottom=0.01  # Marge inférieure minimale
)

# Enregistrer le résultat dans un fichier PDF haute qualité
output_file = "tempN.pdf"
with PdfPages(output_file) as pdf:
    pdf.savefig(fig, dpi=300)  # Résolution élevée pour le PDF

plt.show()

print(f"Les figures combinées haute qualité sont enregistrées dans {output_file}")
