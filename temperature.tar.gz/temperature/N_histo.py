import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm
from matplotlib import cm

# Function to read data from a file
def read_tde_file(file_path):
    data = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) > 1:  # Ensure there are values after dirX
                    values = [float(x) for x in parts[1:]]
                    data.extend(values)
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return data

# Base path
base_folder = os.getcwd()
subfolder = "n"  # Change subfolder to "n"

# Prepare colors for the gradient
files = [f for f in os.listdir(base_folder) if f.startswith("TDE_n_") and f.split('_')[-1].isdigit()]
num_files = len(files)
cmap = cm.get_cmap("coolwarm", num_files)  # Use a better gradient

plt.figure(figsize=(12, 8))

for idx, file_name in enumerate(sorted(files, key=lambda x: int(x.split('_')[-1]))):
    file_path = os.path.join(base_folder, file_name)
    print(f"Processing file: {file_path}")

    # Read data
    data = read_tde_file(file_path)
    if not data:
        print(f"No data found in file {file_name}. Skipped.")
        continue

    # Fit a Gaussian
    mean, std = norm.fit(data)
    xmin, xmax = min(data), max(data)
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mean, std)

    # Gradient color (adjust to make the first curve more visible)
    color = cmap(idx / (num_files - 1))

    # Plot the Gaussian
    plt.plot(x, p, label=f"{file_name} (µ={mean:.2f}, σ={std:.2f})", color=color, linewidth=2)

# Format the graph
plt.title("Gaussian Distributions for TDE_n Files", fontsize=16)
plt.xlabel("Values", fontsize=14)
plt.ylabel("Density", fontsize=14)
plt.ylim(0, 0.017)  # Limit Y scale
plt.legend(fontsize=10, loc="upper right")
plt.grid(alpha=0.3)

# Display and save
output_image = os.path.join(base_folder, "gaussian_distributions_n.png")
plt.savefig(output_image, dpi=600)  # Save with 600 DPI quality
plt.show()
print(f"Graph saved: {output_image}")
