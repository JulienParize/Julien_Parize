#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan  1 00:38:23 2025

@author: parizej
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgba

# Function to read data from a file
def read_tde_file(file_path):
    data = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) > 1:  # Ensure there are values after dirX
                    values = [float(x) for x in parts[1:]]
                    data.extend(values)
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return data

# Base path
base_folder = os.getcwd()

# Separate files into TDE_ga and TDE_n
ga_files = sorted([f for f in os.listdir(base_folder) if f.startswith("TDE_ga_") and f.split('_')[-1].isdigit()],
                  key=lambda x: int(x.split('_')[-1]))
n_files = sorted([f for f in os.listdir(base_folder) if f.startswith("TDE_n_") and f.split('_')[-1].isdigit()],
                 key=lambda x: int(x.split('_')[-1]))

# Define colors and gradients
blue_base = np.array(to_rgba('#4682B4'))  # Base blue
orange_base = np.array(to_rgba('#FFA500'))  # Base orange

# Custom labels for each file
custom_labelsga = {
    "TDE_ga_0": "Ga TDE at 0K",
    "TDE_ga_200": "Ga TDE at 200K",
    "TDE_ga_300": "Ga TDE at 300K",
    "TDE_ga_500": "Ga TDE at 500K",
    # Add more labels as needed for other files
}
# Custom labels for each file
custom_labelsn = {
    "TDE_n_0": "N TDE at 0K",
    "TDE_n_200": "N TDE at 200K",
    "TDE_n_300": "N TDE at 300K",
    "TDE_n_500": "N TDE at 500K",
    # Add more labels as needed for other files
}



# Create gradients
ga_colors = [
    tuple((blue_base[:3] * (1 - 0.2 * i)).clip(0, 1)) + (blue_base[3],)
    for i in range(len(ga_files))
]
n_colors = [
    tuple((orange_base[:3] * (1 - 0.2 * i)).clip(0, 1)) + (orange_base[3],)
    for i in range(len(n_files))
]

# Process TDE_ga files
for idx, file_name in enumerate(ga_files):
    file_path = os.path.join(base_folder, file_name)
    print(f"Processing file: {file_path}")

    # Read data
    data = read_tde_file(file_path)
    if not data:
        print(f"No data found in file {file_name}. Skipped.")
        continue
    
    labell = custom_labelsga.get(file_name, f"Histogram for {file_name}")
    
    # Create the plot
    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=90, density=True, alpha=0.6, color=ga_colors[idx], label=labell)

    # Format the graph
    plt.xlim(0, 110)
    plt.grid(True, which='major', axis='y', linewidth=0.5)
    plt.xlabel("TDE (eV)", fontsize=16)
    plt.ylabel("Distribution", fontsize=16)
    plt.tick_params(axis='x', labelsize=14)
    plt.tick_params(axis='y', labelsize=14)
    plt.legend(fontsize=18)

    # Save and show the graph
    output_image = os.path.join(base_folder, f"{file_name}_histogram.pdf")
    plt.savefig(output_image, dpi=600, bbox_inches='tight')
    plt.show()
    print(f"Graph saved: {output_image}")

# Process TDE_n files
for idx, file_name in enumerate(n_files):
    file_path = os.path.join(base_folder, file_name)
    print(f"Processing file: {file_path}")

    # Read data
    data = read_tde_file(file_path)
    if not data:
        print(f"No data found in file {file_name}. Skipped.")
        continue
    
    
    labeln = custom_labelsn.get(file_name, f"Histogram for {file_name}")

    # Create the plot
    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=90, density=True, alpha=0.6, color=n_colors[idx], label=labeln)

    # Format the graph
    plt.xlim(40, 220)
    plt.grid(True, which='major', axis='y', linewidth=0.5)
    plt.xlabel("TDE (eV)", fontsize=16)
    plt.ylabel("Distribution", fontsize=16)
    plt.tick_params(axis='x', labelsize=14)
    plt.tick_params(axis='y', labelsize=14)
    plt.legend(fontsize=18)

    # Save and show the graph
    output_image = os.path.join(base_folder, f"{file_name}_histogram.pdf")
    plt.savefig(output_image, dpi=600, bbox_inches='tight')
    plt.show()
    print(f"Graph saved: {output_image}")
