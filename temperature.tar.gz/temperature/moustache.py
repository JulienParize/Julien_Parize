import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm

# Function to read data from a file
def read_tde_file(file_path):
    data = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) > 1:  # Ensure there are values after dirX
                    values = [float(x) for x in parts[1:]]
                    data.extend(values)
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return data

# Base path
base_folder = os.getcwd()

# Filter files to include only those matching the expected naming pattern
files = [
    f for f in os.listdir(base_folder)
    if f.startswith("TDE_n_") and f.split('_')[-1].split('.')[0].isdigit()
]

num_files = len(files)

if num_files == 0:
    print("No files found starting with 'TDE_ga_'. Please check the directory.")
else:
    # Prepare data for boxplots
    all_data = []
    labels = []

    for idx, file_name in enumerate(sorted(files, key=lambda x: int(x.split('_')[-1].split('.')[0]))):
        file_path = os.path.join(base_folder, file_name)
        print(f"Processing file: {file_path}")

        # Read data
        data = read_tde_file(file_path)
        if not data:
            print(f"No data found in file {file_name}. Skipped.")
            continue

        all_data.append(data)
        labels.append(file_name)


    # Create boxplot
    plt.figure(figsize=(12, 8))
    y_ticks = np.arange(0, max([max(d) for d in all_data]) + 1, 10)  # More frequent y-ticks
    plt.yticks(y_ticks)
    plt.ylim(30, 220)  # Set custom y-axis limits

    # Define custom colors
    colors = ['#4682B4', '#FFA500', '#800080', '#FFD700'] * (num_files // 4 + 1)
    colors = colors[:num_files]

    boxplot = plt.boxplot(all_data, vert=True, patch_artist=True, labels=labels, sym='o',
                          meanline=True, showmeans=True,  # Display the mean line
                          medianprops=dict(color='black'),
                          meanprops=dict(color='red', linestyle='--', linewidth=2),
                          boxprops=dict(linewidth=2),
                          whiskerprops=dict(linewidth=2),
                          capprops=dict(linewidth=2))

    # Apply custom colors to boxes
    for box, color in zip(boxplot['boxes'], colors):
        box.set_facecolor(color)

    # Format the graph
    plt.xlabel("Temperature", fontsize=16)
    plt.ylabel("TDE (eV)", fontsize=16)
    plt.tick_params(axis='x', labelsize=14)
    plt.tick_params(axis='y', labelsize=14)
    plt.grid(True, which='major', axis='y', linewidth=0.5)
    plt.gca().yaxis.set_major_locator(plt.MultipleLocator(10))
    plt.minorticks_on()
    plt.xticks(ticks=np.arange(1, len(all_data) + 1), labels=['0 K', '200 K', '300 K', '500 K'], rotation=0, ha='center')

    # Display and save
    output_image = os.path.join(base_folder, "boxplots_n.pdf")
    plt.tight_layout()
    plt.savefig(output_image, dpi=600)  # Save with 600 DPI quality
    plt.show()
    print(f"Graph saved: {output_image}")
