import fitz  # PyMuPDF
import os

# Paths to the PDF files
base_folder = os.getcwd()
main_pdf_path = os.path.join(base_folder, "boxplots_n.pdf")
overlay_pdf_path = os.path.join(base_folder, "boxplot_TDE_n_0.pdf")
output_pdf_path = os.path.join(base_folder, "merged_output.pdf")

# Open the main PDF and the overlay PDF
main_pdf = fitz.open(main_pdf_path)
overlay_pdf = fitz.open(overlay_pdf_path)

# Select the page from the overlay PDF
overlay_page = overlay_pdf[0]

# Get dimensions of the main PDF's first page
main_page = main_pdf[0]
main_width, main_height = main_page.rect.width, main_page.rect.height

# Define the position and size for the overlay
overlay_width = main_width * 0.20  # Example: Scale overlay to 50% of main page width
overlay_height = overlay_width * (overlay_page.rect.height / overlay_page.rect.width)  # Maintain aspect ratio
overlay_x = main_width * 0.079  # Example: Center overlay horizontally
overlay_y = main_height * 0.10  # Example: Position overlay 25% from the top

# Insert the overlay onto the main page
main_page.show_pdf_page(
    fitz.Rect(overlay_x, overlay_y, overlay_x + overlay_width, overlay_y + overlay_height),
    overlay_pdf,
    0  # Page number from the overlay PDF
)

# Save the merged output
main_pdf.save(output_pdf_path)

# Close the PDFs
main_pdf.close()
overlay_pdf.close()

print(f"Merged PDF saved to {output_pdf_path}")
