import os
import numpy as np
import matplotlib.pyplot as plt

# Function to read data from a file
def read_tde_file(file_path):
    data = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) > 1:  # Ensure there are values after dirX
                    values = [float(x) for x in parts[1:]]
                    data.extend(values)
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return data

# Base path
base_folder = os.getcwd()
file_name = "TDE_n_0"  # Specific file
file_path = os.path.join(base_folder, file_name)

# Read data
print(f"Processing file: {file_path}")
data = read_tde_file(file_path)

if not data:
    print(f"No data found in file {file_name}. Exiting.")
else:
    # Create boxplot
    plt.figure(figsize=(4, 6))
    plt.boxplot(data, vert=True, patch_artist=True, labels=[''], sym='o', flierprops=dict(marker='o', markersize=8),
                meanline=True, showmeans=True,  # Display the mean line
                medianprops=dict(color='black'),
                meanprops=dict(color='red', linestyle='--', linewidth=2),
                boxprops=dict(linewidth=4),
                whiskerprops=dict(linewidth=2),
                capprops=dict(linewidth=2))

    # Zoom on specific range
    plt.ylim(65, 95)  # Apply zoom for y-axis

    # Format the graph
    plt.tick_params(axis='x', labelsize=12)
    plt.tick_params(axis='y', labelsize=18)
    plt.grid(True, which='major', axis='y', linewidth=0.5)
    plt.tight_layout()

    # Save and show
    output_image = os.path.join(base_folder, f"boxplot_{file_name}.pdf")
    plt.savefig(output_image, dpi=600)  # Save with 600 DPI quality
    plt.show()
    print(f"Graph saved: {output_image}")
