#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan  1 00:37:31 2025

@author: parizej
"""

import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

# Function to read data from a file
def read_tde_file(file_path):
    data = []
    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) > 1:  # Ensure there are values after dirX
                    values = [float(x) for x in parts[1:]]
                    data.extend(values)
    except Exception as e:
        print(f"Error reading file {file_path}: {e}")
    return data

# Base path
base_folder = os.getcwd()

# List of files
files = [f for f in os.listdir(base_folder) if f.startswith("TDE_n_") and f.split('_')[-1].isdigit()]

# Process each file individually
for file_name in sorted(files, key=lambda x: int(x.split('_')[-1])):
    file_path = os.path.join(base_folder, file_name)
    print(f"Processing file: {file_path}")

    # Read data
    data = read_tde_file(file_path)
    if not data:
        print(f"No data found in file {file_name}. Skipped.")
        continue

    # Fit a Gaussian
    mean, std = norm.fit(data)
    xmin, xmax = min(data), max(data)
    x = np.linspace(xmin, xmax, 100)
    p = norm.pdf(x, mean, std)

    # Create the plot
    plt.figure(figsize=(10, 6))
    plt.hist(data, bins=30, density=True, alpha=0.6, color='blue', label="Histogram")
    plt.plot(x, p, 'r-', linewidth=2, label=f"Gaussian (µ={mean:.2f}, σ={std:.2f})")

    # Format the graph
    plt.title(f"Histogram and Gaussian for {file_name}", fontsize=16)
    plt.xlabel("Values", fontsize=14)
    plt.ylabel("Density", fontsize=14)
    plt.legend(fontsize=12)
    plt.grid(alpha=0.3)

    # Save and show the graph
    output_image = os.path.join(base_folder, f"{file_name}_histogram_gaussian.png")
    plt.savefig(output_image, dpi=300)
    plt.show()
    print(f"Graph saved: {output_image}")
